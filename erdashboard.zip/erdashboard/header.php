<?php
require_once 'core/init.php';

 if (Session::exists('home')) {
 	echo Session::flash('home');
 }

 $user   = new User();


if($user->isLoggedIn() ){
	include_once 'views/views.admin.php';
	if (!$user->hasPermission('admin')) {
		//redirect to admin page
		Redirect::to(404);
	}

	}else{
		include 'login.php';
	}

