<?php

//require_once __DIR__.'/vendor/autoload.php';
include_once 'views/sidebar.php';

 $user = new User();

  try{
    $user->createMedic(array(
      'name' => Input::get('name'),
      'title' => Input::get('specialty'),
      'descriotion' => "",
      'contact' => Input::get('number'),
      'doc_image'=>""

    ));

  }catch(Exception $e){
    die($e->getMessage()); //can redirect user here
  }

?>

<!-- Page content -->
<div id="page-content">
    <!-- Contacts Header -->
    <div class="content-header">
        <div class="header-section">
            <h1>
                <i class="gi gi-parents"></i>Doctors<br><small>Add details</small>
            </h1>
        </div>
    </div>
    <!-- Main Row -->
    <div class="row">
    	
<!-- Basic Form Elements Block -->
<div class="block">
    <!-- Basic Form Elements Content -->
    <form action="upload.php" method="post" enctype="multipart/form-data" class="form-horizontal form-bordered">
        <div class="form-group">
            <label class="col-md-3 control-label" for="example-text-input">Name</label>
            <div class="col-md-9">
                <input type="text" id="example-text-input" name="name" class="form-control" placeholder="Name" required>
            </div>
        </div>   
        <div class="form-group">
            <label class="col-md-3 control-label" for="example-textarea-input">Address</label>
            <div class="col-md-9">
                <input type="text" id="example-text-input" name="address" class="form-control" placeholder="Address" required>
            </div>
        </div>
        <div class="form-group">
            <label class="col-md-3 control-label" for="example-textarea-input">Contact number</label>
            <div class="col-md-9">
                <input type="number" id="example-text-input" name="number" class="form-control" placeholder="Contact number" required>
            </div>
        </div>
        <div class="form-group">
            <label class="col-md-3 control-label" for="example-chosen-multiple">Specialty</label>
            <div class="col-md-9">
                <select id="example-chosen" name="specialty" class="select-chosen" data-placeholder="Specialty..." style="width: 250px;">
                    <option value="Paediatrician">Paediatrician </option>
                    <option value="Gynaecologist">Gynaecologist</option>
                    <option value="Dentist">Dentist</option>
                    <option value="GP">General Practicioner</option>
                </select>
            </div>
        </div>

        <div class="form-group form-actions">
            <div class="col-md-9 col-md-offset-3">
                <button type="submit" name="submit" class="btn btn-sm btn-primary"><i class="fa fa-angle-right"></i> Submit</button>
            </div>
        </div>
    </form>
    <!-- END Basic Form Elements Content -->
</div>
<!-- END Basic Form Elements Block -->
    </div>
</div>    


<?php include_once 'footer.php' ?>