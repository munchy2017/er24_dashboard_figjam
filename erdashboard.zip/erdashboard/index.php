<?php
require_once 'core/init.php';
 if (Session::exists('home')) {
 	echo Session::flash('home');
 }

$user   = new User();

if($user->isLoggedIn() ){
	// if (!$user->hasPermission('admin')) {
	// //redirect to admin page
	// Redirect::to(404);
	// }
	include_once 'views/dashboard.php';

	}else{
		Redirect::to('login.php');
	}