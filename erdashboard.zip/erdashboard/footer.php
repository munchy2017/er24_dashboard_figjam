        <!-- Include Jquery library from Google's CDN but if something goes wrong get Jquery from local file (Remove 'http:' if you have SSL) -->
        <script>
           /* var crop;
            window.onload = function(){
                var canvas = document.getElementById('imageCanvas');
                var width = 285;
                var height = 437;
                crop = new ImageCropper(canvas, canvas.width / 2 - width / 2, canvas.height / 2 - height / 2, width, height, true);
                window.addEventListener('mouseup', preview);

            };



            function preview(){
                if ( crop.isImageSet() ) {
                    var img = crop.getCroppedImage(170, 261);
                    img.onload = (function(){
                        return previewLoaded(img);
                    });
                }
            }



            function previewLoaded(img){
                if ( img ) {
                    document.getElementById("preview").appendChild(img); //img is the cropped img
                }
            }



            function handleFileSelect(evt){
                var file = evt.target.files[0];
                var reader = new FileReader();
                var img = new Image();

                //listener for firefox
                img.addEventListener("load", function(){
                    crop.setImage(img);
                    preview();
                }, false);

                reader.onload = function(){
                    img.src = reader.result;

                };

                if (file) {
                    reader.readAsDataURL(file);
                   reader.onloadend = function(){
                      //alert(reader.result);
                      var http = new XMLHttpRequest();
                      var url = "upload.php";
                      

                      
                      http.onreadystatechange = function(){
                        if (http.readyState == 4 && http.status == 200) {
                            console.log(http.responseText);
                        }
                      }
                       http.open('POST', url, true);
                      http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                      http.send("img="+reader.result); //this is original uncrpped img
                      
                   }
                }
            }
            document.getElementById('file-input').addEventListener('change', handleFileSelect, false);*/

        </script>
        <script src="includes/assets/js/ImageCropper.js"></script>
        <script src="includes/assets/js/jquery.js"></script>
        <script src="includes/assets/js/jquery-ui.js"></script>
        <!-- Bootstrap.js, Jquery plugins and Custom JS code -->
        <script src="includes/assets/js/vendor/bootstrap.min.js"></script>
        <script src="includes/assets/js/plugins.js"></script>
        <script src="includes/assets/js/app.js"></script>
        <script src="includes/assets/js/custom.js"></script>
        <!-- Load and execute javascript code used only in this page -->
        <script src="includes/assets/js/pages/index.js"></script>
        <script>$(function(){ Index.init(); });</script>
    </body>
</html>