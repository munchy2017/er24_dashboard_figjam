<?php
    if (isset($_FILES['thumbnail'])  ) {
        $file_name   = $_FILES['thumbnail']['name'];
        $file_size   = $_FILES['thumbnail']['size'];
        $file_type   = $_FILES['thumbnail']['type'];
        $temp_name   = $_FILES['thumbnail']['tmp_name'];

       
        $thumbnails  = "thumbnails/";
        $thumb_url   = BASE_URL.$thumbnails.$file_name;



        if ( !move_uploaded_file($temp_name, $thumbnails.$file_name) ){
            echo $_FILES['thumbnail']['error'];
           
        }else{

        echo $thumb_url;
        }

    }


    if ( isset($_FILES['video'])  ) {
        $video_name  = $_FILES['video']['name'];
        $video_size  = $_FILES['video']['size'];
        $video_type  = $_FILES['video']['type'];
        $video_temp  = $_FILES['video']['tmp_name'];

        $videos      = "videos/";
        $vid_url     = BASE_URL.$videos.$video_name;


        

            if ( !move_uploaded_file($video_temp, $videos.$video_name) ) {
               echo "The video was not uploaded ".$_FILES['video']['error'];
            }else{

        echo $vid_url;
        }

    }



    if (Input::exists()) {
       $movie  = new Movies();

       try{
        $movie->create( array(
                'title' => Input::get('title'),
                'synopsis' => Input::get('synopsis'),
                'video_url' => $vid_url,
                'thumb_url' => $thumb_url,
                'genre' =>  Input::get('genres'),
                'year' => Input::get('year'),
                'starring' => Input::get('starring'),
                'rating' => Input::get('rating'),
                'date_added' => date('Y-m-d H:i:s'),
                'movie_uid' => time().uniqid()
            ) );
       }catch(Exception $e){
            die($e->getMessage());
       }
    }

   
?>

<!-- Basic Form Elements Block -->
<div class="block">
    <!-- Basic Form Elements Content -->
    <form action="" method="post" enctype="multipart/form-data" class="form-horizontal form-bordered">
        <div class="form-group">
            <label class="col-md-3 control-label" for="example-text-input">Title</label>
            <div class="col-md-9">
                <input type="text" id="example-text-input" name="title" class="form-control" placeholder="Movie Title">
            </div>
        </div>   
        <div class="form-group">
            <label class="col-md-3 control-label" for="example-textarea-input">Synopsis</label>
            <div class="col-md-9">
                <textarea id="example-textarea-input" name="synopsis" rows="9" class="form-control" placeholder="Synopsis..."></textarea>
            </div>
        </div>
        <div class="form-group">
            <label class="col-md-3 control-label" for="example-file-input">Movie Url</label>
            <div class="col-md-9">
                <input type="file" id="example-file-input" name="video">
            </div>
        </div>
        <div class="form-group">
            <label class="col-md-3 control-label" for="example-file-input">Select thumbnail</label>
            <div class="col-md-9">
                <input type="file" id="example-file-input" name="thumbnail">
            </div>
        </div>
        <div class="form-group">
            <label class="col-md-3 control-label" for="example-chosen-multiple">Genres</label>
            <div class="col-md-9">
                <select id="example-chosen-multiple" name="genres" class="select-chosen" data-placeholder="Choose a Genre..." style="width: 250px;" multiple>
                    <option value="Action">Action </option>
                    <option value="Adventure">Adventure</option>
                    <option value="Comedy">Comedy</option>
                    <option value="Drama">Drama</option>
                    <option value="Horror">Horror</option>
                </select>
            </div>
        </div>
        <div class="form-group">
            <label class="col-md-3 control-label" for="example-chosen-multiple">Year</label>
            <div class="col-md-9">
                <input type="text" id="example-datepicker5" name="year" class="form-control input-datepicker-close" data-date-format="yyyy" placeholder="yyyy">
            </div>
        </div>

         <div class="form-group">
            <label class="col-md-3 control-label" for="example-text-input">Starring</label>
            <div class="col-md-9">
                <input type="text"  name="starring" id="example-tags" class="input-tags"  placeholder="Starring">
            </div>
        </div> 
        <div class="form-group">
            <label class="col-md-3 control-label" for="example-select">Rating</label>
            <div class="col-md-9">
                <select id="example-select" name="rating" class="form-control" size="1">
                    <option value="0">Please select</option>
                    <option value="All">All</option>
                    <option value="PG">PG</option>
                    <option value="P13">PG13</option>
                    <option value="PG16">PG16</option>
                    <option value="18SNVL">18SNVL</option>
                </select>
            </div>
        </div>

        <div class="form-group form-actions">
            <div class="col-md-9 col-md-offset-3">
                <button type="submit" name="submit" class="btn btn-sm btn-primary"><i class="fa fa-angle-right"></i> Submit</button>
            </div>
        </div>
    </form>
    <!-- END Basic Form Elements Content -->
</div>
<!-- END Basic Form Elements Block -->
