<?php
require_once 'core/init.php';
include_once 'header.php';