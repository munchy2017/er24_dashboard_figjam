<?php
require_once __DIR__.'/vendor/autoload.php';
include_once 'views/sidebar.php';
include_once 'views/functions.php';

?>

<!-- Page content -->
<div id="page-content">
    <!-- Blank Header -->
    <div class="content-header">
        <div class="header-section">
            <h1>
                <i class="gi gi-brush"></i> Doctors<br><small>Click on the title to edit the doctor details</small>
            </h1>
        </div>
    </div>
    <!-- END Blank Header -->

    <!-- Block -->
    <div class="block">
        <!-- Title -->
        <div class="block-title">
            <h2>Edit Details</h2>
        </div>
        <!-- END Title -->

        <!--Content -->
        <div class="row">
			
		</div>
        <!-- END Example Content -->
    </div>
    <!-- END Block -->
</div>
<!-- END Page Content -->


<?php include_once 'footer.php' ?>
