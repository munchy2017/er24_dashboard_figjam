$(document).ready(function(){
	$('.editadmin').click(function(e){ //this onclick is no longer necesary, but its cute c
		e.preventDefault();
		var id  = $(this).prop('id');
		var target = "#" + this.getAttribute('data-target');




		$('html, body').animate({
			scrollTop: $(this).offset().top
		}, 800);



		$('.div-noborder').switchClass("div-noborder", "div-highlighted", 1000, function(){
			 $(this).switchClass("div-highlighted", "div-noborder", 2000, 'linear' );
			});



		$.ajax({
			url: "users.php",
			type: "POST",
			data: {
				id:id,
				action: "updateuser"
			},
			success: function(result){
				//alert(id);
			},
			error: function(result){
				alert("errr");
			}


		});




	}); //end editt admin click
});