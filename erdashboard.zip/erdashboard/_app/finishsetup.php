<?php
require_once 'core/init.php';
$user = new User();

	$user->update(array(
		"email" => Input::get('email'), 
		"phone" => Input::get('phone'),
		"suffix"=> Input::get('suffix'),
		"address"=> Input::get('address'),
		"gender"=> Input::get('gender'),
		"bloodtype"=> Input::get('bloodtype'),
		"emergency_contact"=> Input::get('emergencyContact'),
		"allergies"=> Input::get('allergy'),
		"medical_aid"=> Input::get('medicalAid')
	), Input::get('id')
);