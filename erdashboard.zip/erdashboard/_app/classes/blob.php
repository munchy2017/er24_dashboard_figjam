<?php
//require_once 'vendor/autoload.php';
//include_once  'vendor/microsoft/windowsazure/src/Common/ServicesBuilder.php';
use MicrosoftAzure\Storage\Blob\Models\CreateContainerOptions;
use MicrosoftAzure\Storage\Blob\Models\PublicAccessType;
use MicrosoftAzure\Storage\Common\ServiceException;
	class Blob {
		public $accountKey, $accountName;

		public function __construct(){
		    $this->accountKey="awertv 345sdqe234oreNsdfbY33SFgilaf2ehTNjfiJzuRePpMZsgt345taegf";
		    $this->accountName="vodcastwe01rgdiag963";


		}
		


		public  function createCont(){
	        $connectionString = "DefaultEndpointsProtocol=https;AccountName=".$this->accountName.";AccountKey=".$this->accountKey;
	        // Create blob REST proxy.
	        $blobRestProxy = ServicesBuilder::getInstance()->createBlobService($connectionString);
	        
	        // Create container options object.
	        $createContainerOptions = new CreateContainerOptions();
	        
	        $createContainerOptions->setPublicAccess(PublicAccessType::CONTAINER_AND_BLOBS);
	        
	        try {
	            // Create container.
	            $blobRestProxy->createContainer("videos", $createContainerOptions);
	        }
	        catch(ServiceException $e){
	            // Handle exception based on error codes and messages.
	            // Error codes and messages are here:
	            // http://msdn.microsoft.com/library/azure/dd179439.aspx
	            $code = $e->getCode();
	            $error_message = $e->getMessage();
	            echo $code.": ".$error_message."<br />";
	        }
	        
	        return "Container created";
    }




    	public  function createBlob($video){
	        $connectionString = "DefaultEndpointsProtocol=https;AccountName='vodcastwe01rgdiag963';AccountKey='awertv 345sdqe234oreNsdfbY33SFgilaf2ehTNjfiJzuRePpMZsgt345taegf'";
	        // Create blob REST proxy.
	        $blobRestProxy = ServicesBuilder::getInstance()->createBlobService($connectionString);
	        
	        $file = $video;//"\Pictures\images.png";
	        
	        if(is_readable($file)){
	            $content = fopen($file, "r");
	        }else{
	            return "File not found";
	        }

	        $blob_name = "myblob";
	        
	        try {
	            //Upload blob
	            $blobRestProxy->createBlockBlob("videos", $blob_name, $content);
	        }
	        catch(ServiceException $e){
	            // Handle exception based on error codes and messages.
	            // Error codes and messages are here:
	            // http://msdn.microsoft.com/library/azure/dd179439.aspx
	            $code = $e->getCode();
	            $error_message = $e->getMessage();
	            echo $code.": ".$error_message."<br />";
	        }
	        
	        return "file uploaded";
    }






}