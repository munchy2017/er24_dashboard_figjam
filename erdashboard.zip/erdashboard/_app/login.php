<?php
require_once 'core/init.php';

	if (Input::exists()) {
		//if (Token::check(Input::get('token'))) {
			$validate   = new Validate();
			$validation = $validate->check($_POST, array(
					'username' => array('required' => true),
					'password' => array('required' => true)
				));

			if ($validation->passed()) {
				$user    = new User();
				$login   = $user->login(Input::get('username'), Input::get('password'));

				if ($login) {
					if ($user->find( Input::get('username') ) ) {
			  			$userdata = $user->data();
			  		}
						echo json_encode((object)[
						"error"   => false,
						"uid" 	  => $userdata->uid,
					 	"username"=> $userdata->username,
					 	"name" 	  => $userdata->name
					]);
				}else{
					echo json_encode((object)["error"=>true]);
				}
			}else{
				foreach ($validation->errors() as $error) {
					echo $error.'<br>';
				}
			}
		// }
	}

?>
