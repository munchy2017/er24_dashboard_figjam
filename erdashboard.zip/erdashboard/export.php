<?php
ob_start();
session_start();

$GLOBALS['config'] = array(
	'mysql'  => array(
		'host'     => '127.0.0.1',
		'username' => 'root',
		'password' => '',
		'db'       => 'lr'
		), 
	'remember' => array(
		'cookie_name' => 'hash',
		'cookie_expiry'=> '604800'
		),
	'session' => array(
		'session_name' => 'user',
		'token_name'   => 'token',
		)
	);
//autoloading
spl_autoload_register( function($class){
	require_once 'classes/' . $class . '.php';
} );


require_once 'functions/sanitize.php'; 

if (Cookie::exists(Config::get('remember/cookie_name'))  && !Session::exists(Config::get('session/session_name'))  ){
	$hash   = Cookie::get(Config::get('remember/cookie_name'));
	$hashCheck = DB::getInstance()->get('users_session', array('hash', '=', $hash));

	if ($hashCheck->count()) {
		$user    = new User($hashCheck->first()->users_id);
		$user->login();
	}
}


$subscribers = DB::getInstance()->query("SELECT * FROM users") ;

if (! $subscribers->count() ) {
	echo "No subscribers found";
}else{
	$delimiter  = ",";
	$filename	= "subscribers_".date('Y-m-d H:i:s').".csv";
	$f 			= fopen('php://memory', 'w');
	$fields		= array("User Email", "Full Name", "Date Joined", "Country");

	fputcsv($f, $fields, $delimiter);

	foreach($subscribers->results() as $subscriber) {
	    $email   = $subscriber->username;
	    $name    = $subscriber->name;
	    $date    = '"'.$subscriber->joined.'"';
	    $country = $subscriber->country;
	    $linedata= array($email, $name, $date, $country);
	    fputcsv($f, $linedata, $delimiter);
	}
	fseek($f, 0);
	header('Content-Type: text/csv');
	header('Content-Disposition: attachment; filename="'.$filename.'";');
	fpassthru($f);	
}
