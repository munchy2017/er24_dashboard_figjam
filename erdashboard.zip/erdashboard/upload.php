<?php
include_once 'core/init.php';

// $img =  $_POST['img']; echo $img; die;
// $img = explode("," , $img);


// $t=time();
// $path = "thumbnails/$t.jpg";
// file_put_contents($path, (base64_decode($img[1]) ) );

// die;
 if (isset($_FILES['thumbnail'])  ) {
        if ($_FILES['thumbnail']['error']) {
            echo "Error: ".$_FILES['thumbnail']['error'] . "<br/>";

    }else{
        //accepted file types
        $validextensions = array('.jpg', '.jpeg', '.png');
        $fileExtension  = strrchr($_FILES['thumbnail']['name'], ".")  ;
        if ( in_array($fileExtension, $validextensions) ) {
            $file_name   = $_FILES['thumbnail']['name'];
        $file_size   = $_FILES['thumbnail']['size'];
        $file_type   = $_FILES['thumbnail']['type'];
        $temp_name   = $_FILES['thumbnail']['tmp_name'];

       
        $thumbnails  = "thumbnails/";
        $thumb_url   = BASE_URL.$thumbnails.$file_name;



        if ( !move_uploaded_file($temp_name, $thumbnails.$file_name) ){
            echo $_FILES['thumbnail']['error'];
           
        
         }else{
            echo "Upload an image file";
         }

    }
}}

    if ( isset($_FILES['video'])  ) {
        $video_name  = $_FILES['video']['name'];
        $video_size  = $_FILES['video']['size'];
        $video_type  = $_FILES['video']['type'];
        $vid_temp    = $_FILES['video']['tmp_name'];
        $ffmpeg = "C:\\ffmpeg\\bin\\ffmpeg";
        $imageFile = time().".jpg";
        $size = "600x400";
        $getFromSecond = 5;
        $cmd = "$ffmpeg -i $vid_temp -an -ss $getFromSecond -s $size posters/$imageFile";

        if (!shell_exec($cmd)) {
            echo "Error creating thumbnail";
        }else{
            echo "Suceess ";
        }

        move_uploaded_file($vid_temp, "videos/".$video_name);
        $videos  = "videos/";
        $vid_url   = BASE_URL.$videos.$video_name;
        $poster_img= "posters/".$imageFile;

        echo $poster_img;


    }


    if (Input::exists()) {
       $movie  = new Movies();

       try{
        $movie->create( array(
                'title' => ucwords(Input::get('title')),
                'synopsis' => ucfirst(Input::get('synopsis')),
                'video_url' => $vid_url,
                'thumb_url' => $thumb_url,
                'poster_img' => $poster_img,
                'genre' =>  Input::get('genres'),
                'year' => Input::get('year'),
                'starring' => Input::get('starring'),
                'rating' => Input::get('rating'),
                'date_added' => date('Y-m-d H:i:s'),
                'movie_uid' => time().uniqid()
            ) );
       }catch(Exception $e){
            die($e->getMessage());
       }
    }

