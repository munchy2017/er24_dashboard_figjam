<?php
require_once 'views/sidebar.php';

if(!$username = Input::get('id')){
    Redirect::to('index.php');
}else{
    $user  = new User($username);
   
        $data  = $user->data();
    }

    ?>

<h3><?php  echo escape($data->username);  ?></h3>
<p>Full Name: <?php  echo escape($data->name);  ?></p>
    <?php


?>
 <!-- Page content -->
<div id="page-content">
    <!-- Blank Header -->
    <div class="content-header">
        <div class="header-section">
            <h1>
                <i class="gi gi-brush"></i>Blank<br><small>A clean page to help you start!</small>
            </h1>
        </div>
    </div>
    <ul class="breadcrumb breadcrumb-top">
        <li>Pages</li>
        <li>Get Started</li>
        <li><a href="">Blank</a></li>
    </ul>
    <!-- END Blank Header -->

    <!-- Example Block -->
    <div class="block">
        <!-- Example Title -->
        <div class="block-title">
            <h2>Edit user</h2>
        </div>
        <!-- END Example Title -->

        <!-- Add Contact Content -->
                <form action="adduser.php" method="post" class="form-horizontal form-bordered">
                    <div class="form-group">
                        <label class="col-xs-3 control-label" for="add-contact-name">Name</label>
                        <div class="col-xs-9">
                            <input type="text" id="add-contact-name" name="name" class="form-control" placeholder="Enter Full Name..."  value="<?php echo escape($data->name) ;  ?>" autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-xs-3 control-label" for="add-contact-email">Email</label>
                        <div class="col-xs-9">
                            <input type="email" id="add-contact-email" name="username" class="form-control" placeholder="Enter Email..." value="<?php echo escape($data->username) ;  ?>" autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-xs-3 control-label" for="add-contact-phone">Password</label>
                        <div class="col-xs-9">
                            <input type="password" id="add-contact-phone" name="password" class="form-control" placeholder="Password..." autocomplete="off">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-xs-3 control-label" for="add-contact-mobile">Repeat password</label>
                        <div class="col-xs-9">
                            <input type="password" id="add-contact-mobile" name="password_again" class="form-control" placeholder="Repeat Password..." autocomplete="off">
                        </div>
                    </div>                                   
                    <div class="form-group">
                        <label class="col-xs-3 control-label" for="add-contact-group">Group</label>
                        <div class="col-xs-9">
                            <select id="" name="group" class="form-control  mr-sm-4" size="1">
                                <option value="">Please select the user's group</option>
                                <option value=2>Super Admin</option>
                                <option value=3>Moderator</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group form-actions">
                        <div class="col-xs-9 col-xs-offset-3">
                            <button type="submit" name="submit" class="btn btn-sm btn-primary"><i class="fa fa-plus"></i> Update Contact</button>
                        </div>
                    </div>
                    <input type ="hidden" name="token" value="<?php echo Token::generate();   ?>">
                </form>
                <!-- END Add Contact Content -->
    </div>
    <!-- END Example Block -->
</div>
<!-- END Page Content -->
<?php include_once 'footer.php' ?>
