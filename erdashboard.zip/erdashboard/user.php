<?php
include_once 'views/sidebar.php';
$id = Input::get('id');
$user = new User();
$appuser = $user->findAppUsers($id);

$name = $appuser->name;
$phone = $appuser->phone;
$addr = $appuser->address;
$bType = $appuser->bloodType;
$gender = $appuser->gender;
$medic = $appuser->medicalAid;
$ice = $appuser->emergencyContact;
$allergy = $appuser->allergy;

?>
  <!-- Page content -->
                <div id="page-content">
                    <!-- Blank Alternative Header -->
                    <div class="content-header">
                        <div class="header-section">
                            <h1>
                                <i class="gi gi-brush"></i>User Profile<br><small>View app users critical information and details</small>
                            </h1>
                        </div>
                    </div>

                    <!-- Blank Alternative Content -->
                    <div class="block block-alt-noborder">
                        <h3 class="sub-header">User <small>Info</small></h3>
                      <div class="row">
                      	  <!--CONTENT-->
                        <div class="col-md-6">
                            <!-- Advanced Active Theme Color Widget Alternative -->
                            <div class="widget">
                                <div class="widget-advanced widget-advanced-alt">
                                    <!-- Widget Header -->
                                    <div class="widget-header text-center themed-background-dark">
                                        <a href="page_ready_user_profile.html">
                                            <img src="img/placeholders/avatars/avatar15.jpg" alt="avatar" class="widget-image img-circle">
                                        </a>
                                        <h4 class="widget-content-light">
                                            <a href="page_ready_user_profile.html"><?php echo $name ?></a><br>
                                            <small><i class="gi gi-pin"></i><?php echo $addr ?></small>
                                        </h4>
                                    </div>
                                    <!-- END Widget Header -->

                                    <!-- Widget Main -->
                                    <div class="widget-main">
                                        <div class="list-group remove-margin">
                                            <a href="javascript:void(0)" class="list-group-item">
                                                <span class="pull-right"><strong><?php echo $phone ?></strong></span>
                                                <h4 class="list-group-item-heading remove-margin"><i class="fa fa-phone fa-fw"></i> Phone</h4>
                                            </a>
                                            <a href="javascript:void(0)" class="list-group-item">
                                                <span class="pull-right"><strong><?php echo $bType ?></strong></span>
                                                <h4 class="list-group-item-heading remove-margin"><i class="fa fa-briefcase fa-fw"></i> Bloodtype</h4>
                                                <p class="list-group-item-text"></p>
                                            </a>
                                            <a href="javascript:void(0)" class="list-group-item">
                                                <span class="pull-right"><strong><?php echo $gender ?></strong></span>
                                                <h4 class="list-group-item-heading remove-margin"><i class="fa fa-users fa-fw"></i> Gender</h4>
                                                <p class="list-group-item-text"></p>
                                            </a>
                                            <a href="javascript:void(0)" class="list-group-item">
                                                <span class="pull-right"><strong><?php echo $ice ?></strong></span>
                                                <h4 class="list-group-item-heading remove-margin"><i class="fa fa-heart fa-fw"></i> ICE</h4>
                                                <p class="list-group-item-text"></p>
                                            </a>
                                            <a href="javascript:void(0)" class="list-group-item">
                                                <span class="pull-right"><strong><?php echo $allergy ?></strong></span>
                                                <h4 class="list-group-item-heading remove-margin"><i class="fa fa-briefcase fa-fw"></i> Allergies</h4>
                                                <p class="list-group-item-text"></p>
                                            </a>
                                            <a href="javascript:void(0)" class="list-group-item">
                                                <span class="pull-right"><strong><?php echo $medic ?></strong></span>
                                                <h4 class="list-group-item-heading remove-margin"><i class="fa fa-ambulance fa-fw"></i> Medical Aid</h4>
                                                <p class="list-group-item-text"></p>
                                            </a>
                                        </div>
                                    </div>
                                    <!-- END Widget Main -->
                                </div>
                            </div>
                            <!-- END Advanced Active Theme Color Widget Alternative -->
                        </div>
                        <!--ENDD CONTENT-->
                      </div>
                    </div>
                    <!-- END Blank Alternative Content -->
                </div>
                <!-- END Page Content -->
<?php include_once 'footer.php' ?>